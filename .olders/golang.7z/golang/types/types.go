package types

type OvhApiCredentials struct {
	ApiZone     string `apizone:"apizone"`
	ApiKey      string `json:"apikey"`
	ApiSecret   string `json:"apisecret"`
	ConsumerKey string `json:"consumerkey"`
}

type RecordDNS struct {
	Id        int    `json:"id"`
	Zone      string `json:"zone"`
	SubDomain string `json:"subDomain"`
	FieldType string `json:"fieldType"`
	Target    string `json:"target"`
	Ttl       int    `json:"ttl"`
}
