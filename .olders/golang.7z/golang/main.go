package main

import (
	"fmt"

	services "wisegar-org/wgo-ddns/services"
	types "wisegar-org/wgo-ddns/types"

	externalip "github.com/glendc/go-external-ip"
)

func main() {
	Version := "v0.0.0-build.00"
	fmt.Println("Version:\t", Version)

	client, err := services.GetOvhClient()
	if err != nil {
		return // TODO: Log and Error Handler
	}

	var domain string = "wisegar.ch"
	defaultDomainExist := services.ExistDomainOnVH(client, domain)
	if !defaultDomainExist {
		return
	}

	zoneRecordId := []int64{}
	zoneRecordId, err = services.GetRootDomainRecordA(client, domain)
	if err != nil {
		fmt.Println(err)
		return
	}
	if len(zoneRecordId) == 0 {
		return
	}

	var recordNDS types.RecordDNS
	err = client.Get(fmt.Sprintf("/domain/zone/%s/record/%d", domain, zoneRecordId[0]), &recordNDS)
	if err != nil {
		fmt.Println(err)
		return
	}

	consensus := externalip.DefaultConsensus(nil, nil)
	ip, err := consensus.ExternalIP()
	if err != nil {
		return
	}
	fmt.Println(ip.String())

	if recordNDS.Target == ip.String() {
		return
	}
	recordNDS.Target = ip.String()
	putUrl := fmt.Sprintf("/domain/zone/%s/record/%d", domain, zoneRecordId[0])
	params := &recordNDS
	err = client.Put(putUrl, params, nil)
	if err != nil {
		fmt.Println(err)
		return
	}
}
