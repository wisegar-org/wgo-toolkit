package services

import (
	"fmt"
	"strings"
	
	types "wisegar-org/wgo-ddns/types"

	"github.com/ovh/go-ovh/ovh"
)

func getCredentials() (types.OvhApiCredentials, error) {
	var credentials types.OvhApiCredentials

	// TODO: Load from configuration file
	credentials.ApiZone = "ovh-eu"
	credentials.ApiKey = "3004b42d363def2c"
	credentials.ApiSecret = "b2a25894c3c6eab925fdad58088c7689"
	credentials.ConsumerKey = "8c79103bca03c5c5c4df6fd2c5c0ae52"

	return credentials, nil
}

func GetOvhClient() (*ovh.Client, error) {
	credentials, err := getCredentials()
	if err != nil {
		return nil, err // TODO: Log and handle error
	}
	client, err := ovh.NewClient(
		credentials.ApiZone,
		credentials.ApiKey,
		credentials.ApiSecret,
		credentials.ConsumerKey,
	)
	if err != nil {
		return nil, err
	}

	return client, nil
}

func GetDomains(client *ovh.Client) ([]string, error) {
	domains := []string{}
	err := client.Get("/domain/zone", &domains)
	if err != nil {
		return nil, err
	}
	return domains, nil
}

func ExistDomainOnVH(client *ovh.Client, domain string) bool {
	var defaultDomainExist bool = false
	domains, err := GetDomains(client)
	if err != nil {
		fmt.Println(err)
		return defaultDomainExist
	}
	for i := 0; i < len(domains); i++ {
		if !strings.Contains(domains[i], domain) {
			continue
		}
		defaultDomainExist = true
		break
	}
	return defaultDomainExist
}

func GetRootDomainRecordA(client *ovh.Client, domain string) ([]int64, error) {
	zoneRecordId := []int64{}
	err := client.Get(fmt.Sprintf("/domain/zone/%s/record?fieldType=A", domain), &zoneRecordId)
	if err != nil {
		fmt.Println(err)
		return zoneRecordId, err
	}
	return zoneRecordId, nil
}

func GetSubDomainRecordA(client *ovh.Client, domain string, subdomain string) ([]int64, error) {
	zoneRecordId := []int64{}
	err := client.Get(fmt.Sprintf("/domain/zone/%s/record?fieldType=A&subDomain=%s", domain, subdomain), &zoneRecordId)
	if err != nil {
		fmt.Println(err)
		return zoneRecordId, err
	}
	return zoneRecordId, nil
}
